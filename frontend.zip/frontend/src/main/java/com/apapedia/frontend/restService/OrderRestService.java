package com.apapedia.frontend.restService;


import com.apapedia.frontend.payloads.OrderDTO;

import java.util.List;

public interface OrderRestService {
    List<OrderDTO> getOrderHistory();
    OrderDTO updateStatus();
}
